# MediBridge Starter

Run: `docker compose up`
