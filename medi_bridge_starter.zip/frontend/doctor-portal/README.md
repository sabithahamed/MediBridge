# Doctor Portal (Vite + React) – emergency mode + notifications
