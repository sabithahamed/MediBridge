# Patient Portal (Vite + React) – set up and call Gateway APIs
